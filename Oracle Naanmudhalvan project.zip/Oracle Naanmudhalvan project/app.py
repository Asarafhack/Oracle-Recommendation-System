from flask import Flask, render_template, request, redirect, url_for, send_from_directory
import csv
import os

app = Flask(__name__)

# Placeholder for cart and favorites
cart = []
favorites = []

# Load product data from CSV file
def load_data():
    data = []
    with open('products.csv', newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            data.append(row)
    return data

# Route to render the search page
@app.route('/')
def search():
    products = load_data()  # Load products data
    return render_template('search.html', products=products, cart=cart)

# Route to handle the search query and render the product details page
@app.route('/product', methods=['POST', 'GET'])
def product():
    product_name = request.form.get('name') or request.args.get('product_name')
    products = load_data()  # Load products data
    product = next((p for p in products if p['name'] == product_name), None)
    is_favorite = product_name in favorites  # Check if the product is in favorites
    return render_template('product.html', product=product, is_favorite=is_favorite)

# Route to serve static files (images)
@app.route('/static/images/<path:image_name>')
def serve_image(image_name):
    return send_from_directory(os.path.join(app.root_path, 'static', 'images'), image_name)

# Route to handle adding product to cart
@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    product_name = request.form['product_name']
    quantity = int(request.form['quantity'])
    cart.append({'name': product_name, 'quantity': quantity})
    return redirect(url_for('search'))

# Route to handle shortlisting product
@app.route('/shortlist', methods=['POST'])
def shortlist():
    product_name = request.form['product_name']
    favorites.append(product_name)
    return redirect(url_for('product', product_name=product_name))

# Route to handle removing product from favorites
@app.route('/remove_from_favorites', methods=['POST'])
def remove_from_favorites():
    product_name = request.form['product_name']
    favorites.remove(product_name)
    return redirect(url_for('view_favorites'))

# Route to handle removing product from cart
@app.route('/remove_from_cart', methods=['POST'])
def remove_from_cart():
    product_name = request.form['product_name']
    for item in cart:
        if item['name'] == product_name:
            cart.remove(item)
            break
    return redirect(url_for('view_cart'))

# Route to render favorites page
@app.route('/favorites')
def view_favorites():
    favorite_products = [product for product in load_data() if product['name'] in favorites]
    return render_template('favorites.html', favorite_products=favorite_products)

# Route to render cart page
@app.route('/cart')
def view_cart():
    cart_with_images = []
    total_price = 0
    for item in cart:
        product = next((p for p in load_data() if p['name'] == item['name']), None)
        if product:
            product['quantity'] = item['quantity']
            cart_with_images.append(product)
            price = float(product['Price'])  # Convert Price to float
            total_price += item['quantity'] * price  # Calculate total price
    return render_template('cart.html', cart=cart_with_images, total_Price=total_price)

# Route to handle placing an order
@app.route('/place_order', methods=['POST'])
def place_order():
    # Implement logic to process the order (e.g., store order details in a database)
    # Once the order is processed, clear the cart
    cart.clear()
    return redirect(url_for('payment'))

# Calculate total price of items in cart
def calculate_total_price():
    total_price = 0
    products = load_data()
    for item in cart:
        product = next((p for p in products if p['name'] == item['name']), None)
        if product:
            total_price += float(product['Price']) * int(item['quantity'])
    return total_price

# Route to render the payment page
@app.route('/payment', methods=['GET', 'POST'])
def payment():
    # Logic to fetch payment methods from database or other source
    payment_methods = ["Credit Card", "PayPal", "Bank Transfer"]
    
    # Calculate total price of items in cart
    total_Price = calculate_total_price()  # Assuming you have a function to calculate total price
    
    if request.method == 'POST':
        # Process the selected payment method
        selected_method = request.form['payment_method']
        # Implement logic to handle the selected payment method
        return redirect(url_for('payment_confirmation'))
    
    return render_template('payment.html', payment_methods=payment_methods, total_Price=total_Price)


# Route to render the payment confirmation page
@app.route('/payment_confirmation')
def payment_confirmation():
    # Logic to confirm the payment and display confirmation page
    return render_template('payment_confirmation.html')

if __name__ == '__main__':
    app.run(debug=True)
