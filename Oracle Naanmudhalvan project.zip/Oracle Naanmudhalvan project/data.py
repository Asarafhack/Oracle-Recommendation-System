import csv
import os

# Define the data
data = [
    {"name": "TUF", "rating": 4, "image_url": "p1.jpg", "Price": 51000, "description": "best laptop"},
    {"name": "ACER", "rating": 3.8, "image_url": "p2a.jpg", "Price": 38000, "description": " good for gaming"},
    {"name": "Lenova", "rating": 3.2, "image_url": "p3l.jpg", "Price": 48000, "description": "its a brand"},
    {"name": "HP Victus", "rating": 3.0, "image_url": "p4wi.jpg", "Price": 58000, "description": "hp is old but it is good"},
    {"name": "Wings nuvobook", "rating": 4.9, "image_url": "p5w.jpg", "Price": 28000, "description": "its for yasir"},
    {"name": "Samsung Galaxy S21", "rating": 4.5, "image_url": "s21.jpg", "Price": 75000, "description": "Flagship Android smartphone with powerful camera and 5G connectivity."},
    {"name": "Google Pixel 5", "rating": 4.2, "image_url": "g.jpg", "Price": 65000, "description": "Pure Android experience with excellent camera quality and fast updates."},
    {"name": "OnePlus 9 Pro", "rating": 4.7, "image_url": "o.jpg", "Price": 72000, "description": "Premium Android smartphone with Hasselblad camera system and fast charging."},
    {"name": "Xiaomi Redmi Note 10", "rating": 4.3, "image_url": "x.jpg", "Price": 30000, "description": "Budget-friendly Android smartphone with high-resolution display and large battery."},
    {"name": "iPhone 15 Pro", "rating": 4.8, "image_url": "i.jpg", "Price": 100000, "description": "Flagship iOS smartphone with LiDAR scanner and 5G connectivity."},
    {"name": "Sony Xperia 1 III", "rating": 4.6, "image_url": "s.jpg", "Price": 85000, "description": "Premium Android smartphone with 4K OLED display and professional camera features."},
    {"name": "Samsung Galaxy Tab S7", "rating": 4.4, "image_url": "so.jpg", "Price": 60000, "description": "High-performance Android tablet with S Pen support and 120Hz display."},
    {"name": "Apple iPad Pro", "rating": 4.9, "image_url": "ap.jpg", "Price": 90000, "description": "Powerful iPad with M1 chip and Liquid Retina XDR display for professional use."},
    {"name": "Dell XPS 15", "rating": 4.7, "image_url": "dell.jpg", "Price": 95000, "description": "Premium Windows laptop with stunning display and exceptional build quality."},
    {"name": "Microsoft Surface Laptop 4", "rating": 4.5, "image_url": "ms.jpg", "Price": 80000, "description": "Sleek and versatile laptop with touch screen and Surface Pen compatibility."}
]

# Define the directory paths
static_dir = 'static'
images_dir = os.path.join(static_dir, 'images')

# Create the static and images directories if they don't exist
os.makedirs(static_dir, exist_ok=True)
os.makedirs(images_dir, exist_ok=True)

# Write data to CSV file
csv_file = os.path.join( 'products.csv')
with open(csv_file, 'w', newline='') as file:
    writer = csv.DictWriter(file, fieldnames=["name", "rating", "image_url", "Price", "description"])
    writer.writeheader()
    writer.writerows(data)

# Move images to the images directory
for product in data:
    image_path = os.path.join(images_dir, product['image_url'])
    with open(image_path, 'wb') as image_file:
        pass

print(f"CSV file '{csv_file}' created successfully.")
