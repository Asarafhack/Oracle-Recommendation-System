import csv

data = [
    {"id": 552, "name": "Sony Turntable - PSLX350H", "description": "Sony Turntable - PSLX350H/ Belt Drive System/ 33-1/3 and 45 RPM Speeds/ Servo Speed Control/ Supplied Moving Magnet Phono Cartridge/ Bonded Diamond Stylus/ Static Balance Tonearm/ Pitch Control", "price": ""},
    {"id": 580, "name": "Bose Acoustimass 5 Series III Speaker System - AM53BK", "description": "Bose Acoustimass 5 Series III Speaker System - AM53BK/ 2 Dual Cube Speakers With Two 2-1/2' Wide-range Drivers In Each Speaker/ Powerful Bass Module With Two 5-1/2' Woofers/ 200 Watts Max Power/ Black Finish", "price": "$399.00"},
    {"id": 4696, "name": "Sony Switcher - SBV40S", "description": "Sony Switcher - SBV40S/ Eliminates Disconnecting And Reconnecting Cables/ Compact Design/ 4 A/V Inputs With S-Video Jacks/ 1 A/V Output With S-Video (Y/C)Jack/ 2 Audio Output", "price": "$49.00"},
    {"id": 5644, "name": "Sony 5 Disc CD Player - CDPCE375", "description": "Sony 5 Disc CD Player- CDPCE375/ 5 Disc Changer/ Variable Line Output/ CD-R/RW Playback Capability/ 20 Track Music Calendar/ Digital Servo Control/ Remote Commander Remote Control", "price": ""},
    {"id": 6284, "name": "Bose 27028 161 Bookshelf Pair Speakers In White - 161WH", "description": "Bose 161 Bookshelf Speakers In White - 161WH/ Articulated Array Speaker Design/ High-Excursion Twiddler Drivers/ Magnetically Shielded/ Priced Per Pair/ White Finish", "price": "$158.00"},
    {"id": 6493, "name": "Denon Stereo Tuner - TU1500RD", "description": "Denon Stereo Tuner - TU1500RD/ RDS Radio Data System/ AM-FM 40 Station Random Memory/ Rotary Tuning Knob/ Dot Matrix FL Display/ Optional Remote", "price": "$375.00"},
    {"id": 6726, "name": "KitchenAid Pasta Roller And Cutter - KPRA", "description": "KitchenAid Pasta Roller And Cutter - KPRA/ One Pasta Roller/ Two Pasta Cutters/ Cleaning Brush/ Chrome Finish", "price": ""},
    {"id": 6742, "name": "Panasonic Yeast Pro Automatic Breadmaker - SDYD250", "description": "Panasonic Yeast Pro Automatic Breadmaker - SDYD250/ Patented Yeast Dispenser/ 2.5 lb To 1.5 lb Loaf/ Choice Of Bread And Baking Modes/ 13 Hour Countdown Digital Timer/ Nonstick Coating For Easy Cleanup", "price": ""},
    {"id": 7195, "name": "Sony Vertical-In-The-Ear Stereo Headphones - MDRJ10", "description": "Sony Vertical-In-The-Ear Stereo Headphones - MDRJ10/ Clip On Style/ 13.5 MM Driver Unit/ Blue Finish", "price": ""},
    {"id": 7783, "name": "Panasonic 2-Line Integrated Telephone - KXTSC14W", "description": "Panasonic 2-Line Integrated Telephone - KXTSC14W/ Call Waiting/ 50-Station Caller ID/ Voice Mail Message-Waiting Indicator/ Speakerphone/ 3-Line LCD Display/ White Finish", "price": ""},
    {"id": 7936, "name": "Panasonic Integrated Telephone System - KXTS108W", "description": "Panasonic Integrated Telephone System - KXTS108W/ 16 Digit LCD With Clock/ Hands Free Speakerphone/ Built-In Data Port/ 10-Station One-Touch Dialing/ 3-Step Ringer Volume/ White Finish", "price": "$44.00"},
    {"id": 8060, "name": "Panasonic 2-Line Integrated Telephone System - KXTS208W", "description": "Panasonic 2-Line Integrated Telephone System - KXTS208W/ 3-Way Conference/ One-Touch/Speed Dialer/ Speakerphone/ White Finish", "price": ""},
    {"id": 8552, "name": "Sony 300 Disc CD Changer - CDPCX355", "description": "Sony 300 Disc CD Changer - CDPCX355/ MegaStorage Control/ CD-R/CD-RW Playback/ 32 Step Program Play/ Control A1 II/ Custom File Memo/ CD Text/ Keyboard Input/ 2 Jog Dials/ Remote Control/ Black Finish", "price": ""},
    {"id": 9071, "name": "Sony 400 Disc MegaStorage CD Changer - CDPCX455", "description": "Sony 400 Disc MegaStorage CD Changer - CDPCX455/ MP3 Playback Capability/ CD-R/CD-RW Playback/ Twin Jog Dial For Easy Disc Access/ MegaChanger Control/ Optical Digital Output/ Keyboard Input/ Remote Commander® Remote Control", "price": ""},
    {"id": 9312, "name": "Panasonic Hands-Free Headset - KXTCA86", "description": "Panasonic Hands-Free Headset - KXTCA86/ Comfort Fit And  Fold Design/ Noise Cancelling Microphone/ Standard 2.5mm Connection", "price": "$14.95"},
    {"id": 9314, "name": "Panasonic Hands Free Headset  - KXTCA92", "description": "Panasonic Hands Free Headset - KXTCA92/ Comfort Fit With Fold Design/ Noise Cancelling Microphone/ Volume Control/ Mute/ Standard 2.5mm Connection", "price": "$25.00"},
    {"id": 9355, "name": "Cuisinart Convection-Oven-Toaster-Broiler With Exact Heat Sensor - TOB165WH", "description": "Cuisinart Convection-Oven-Toaster-Broiler With Exact Heat Sensor - TOB165WH/ 0.5 Cubic Foot Oven Capacity/ LED Indicators/ Individual Or Combination Settings/ Always Even Shade Control/ 4 Hour Automatic Shut Off/ Slide-Out Crumb Tray/ Includes Broiling Pan/ White Finish", "price": "$149.00"},
    {"id": 9546, "name": "Frigidaire 24' White Built-In Dishwasher - FDB130WH", "description": "Frigidaire 24' FDB130RGS White Built-In Dishwasher - FDB130WH/ Convection Drying System/ QuietSound Sound Insulation Package/ 2 Wash Levels/ Adjustable Rinse Aid Dispenser/ Self Cleaning Filter/ White Finish", "price": "$229.00"},
    {"id": 9646, "name": "Cuisinart Cordless Electric Kettle - KUA17", "description": "Cuisinart Cordless Electric Kettle - KUA17/ 1-3/4 Quart Capacity/ Automatic Shut-Off/ Indicator Light/ Splash Guard Spout/ Cord Storage In Base/ Chrome Finish", "price": "$70.00"},
    {"id": 10101, "name": "Omnimount Wall Speaker Mount - 20WLBK", "description": "Omnimount Wall Speaker Mount - 20WLBK/ Stainless Steel Shafts And All Necessary Hardware Included/ Supports Speakers Up To 20 lbs./ Sold As Single / Black Finish", "price": "$39.95"},
    {"id": 10102, "name": "Omnimount Wall Speaker Mount - 20WLWH", "description": "Omnimount Wall Speaker Mount - 20WLWH/ Stainless Steel Shafts And All Necessary Hardware Included/ Supports Speakers Up To 20 lbs./ Sold as each / White Finish (Photo Showing Black)", "price": "$40.00"},
    {"id": 10640, "name": "Denon Semi-Automatic Turntable - Black Finish - DP29F", "description": "Denon Semi-Automatic Turntable - DP29F/ Metal Platter/ Built-In RIAA Equalizer/ DC Servo Motor/ 2 Speed 33 + 45 RPM/ Built-In Phono PreAmp", "price": "$150.00"},
    {"id": 11338, "name": "Sony Xplod 10-Disc Add-On CD/MP3 Changer - CDX565MXRF", "description": "Sony Xplod 10-Disc Add-On CD/MP3 Changer - CDX565MXRF/ CD/CD-R/CD-RW And MP3 Playback/ MP3 Decoding/ D-Bass/ 12-Second Advanced Electronic Shock Protection/ FM Modulator/ 9 Modulation Frequencies/ Wireless Remote", "price": ""},
    {"id": 11801, "name": "Escort Passport Radar And Laser Detector - Black Finish - 8500", "description": "Escort Passport X50 Radar And Laser Detector - 8500/ X-Band, K-Band, Ka-Band Operating Bands/ AlGaAs 280 LED Matrix/Text Display Type/ 3-Level Dimming, Plus Dark Mode/ Auto Mute/ City Mode Sensitivity/ Compact Size/ Red Display", "price": "$313.95"},
    {"id": 13155, "name": "Peerless Wall TV Mounts In Black - PM1327BK", "description": "Peerless Wall TV Mounts - PM1327BK/ TV Wall Mount With Adjustable Width Support Tray For 13'-27' Set/ Black Finish", "price": ""},
    {"id": 13202, "name": "Panasonic Laser Toner Cartridge - KXFA83", "description": "Panasonic Laser Toner Cartridge - KXFA83/ Used With FL511/F541 Fax Machines", "price": ""},
    {"id": 13213, "name": "Sony Compact Disc Player/Recorder - RCDW500C", "description": "Sony Compact Disc Player/Recorder - RCDW500C/ 5-CD/Dual Deck With 4x High Speed Dubbing/ CD, CD-R, CD-RW, MP3 Playback Capable/ Super Bit Mapping Recording/ High Speed Finalizing", "price": "$299.00"}
]

# Write data to CSV
with open('products.csv', 'w', newline='') as csvfile:
    fieldnames = ['id', 'name', 'description', 'price']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

    writer.writeheader()
    for item in data:
        writer.writerow(item)

print("CSV file 'products.csv' has been created successfully.")
